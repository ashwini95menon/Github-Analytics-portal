##### Week 1 (Sprint 1)

Tasks|Issue number|Status
|---|---|---|
Repeatability - research on what parts of the code need to be modified |	 |Complete
Tableau - automation problem to resolve|	|Incomplete
Research on deployment methods - Heroku, Ansible|	|Complete

##### Week 2 (Sprint 2)

Tasks|Issue number|Status
|---|---|---|
Automation scripts|| Complete
Debug Heroku deployment issue faced currently|[#43](https://github.ncsu.edu/adhaval/csc510-project/issues/43)|Complete
Deployment method to finalise according to Tableau and Heroku	|[#44](https://github.ncsu.edu/adhaval/csc510-project/issues/44)|Complete
Work on automation of data ingest/update |[#41](https://github.ncsu.edu/adhaval/csc510-project/issues/41)|Complete
Errors to fix in Python code |[#42](https://github.ncsu.edu/adhaval/csc510-project/issues/42)|Complete
Tableau Online - automation issue to discuss |[#40](https://github.ncsu.edu/adhaval/csc510-project/issues/40)|Complete

##### Week 3 (Sprint 3)

|Tasks|Issue number|Status|
|---|---|---|
|Deployment scripts||Complete
|Complete milestone document	||Complete
|Complete worksheet document	||Complete
|Script for screencast	||Complete
|Screencast recording	- milestone 4||Complete
|Screencast recording - milestone 5||Complete
|Report - draft||Complete
